import Link from "next/link"
import Image from "next/image"
import { Calendar, MapPin, Trophy, Users, Search, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen max-w-[1920px] mx-auto">
      <header className="sticky top-0 z-40 w-full border-b bg-background">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2 transition-transform hover:scale-105">
              <div className="relative w-8 h-8">
                <Image src="/images/mechaleague-logo.png" alt="MechaLeague" width={32} height={32} />
              </div>
              <span className="inline-block font-bold">MechaLeague</span>
            </Link>
            <nav className="hidden md:flex gap-6">
              <Link href="/" className="flex items-center text-sm font-medium text-foreground">
                Home
              </Link>
              <Link
                href="/teams"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Teams
              </Link>
              <Link
                href="/tournaments"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Tournaments
              </Link>
              <Link
                href="/about"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                About
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <div className="relative w-full max-w-sm mr-4 hidden md:flex">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search teams, tournaments..."
                className="pl-8 w-full transition-all focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <nav className="flex items-center space-x-2">
              <Button variant="outline" size="icon" asChild className="hover:bg-primary/10 transition-colors">
                <Link href="/search">
                  <Search className="h-4 w-4" />
                  <span className="sr-only">Search</span>
                </Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-1 w-full">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/30">
          <div className="container px-4 md:px-6 max-w-[1600px] mx-auto">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2 animate-in fade-in slide-in-from-bottom-4 duration-700">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">Welcome to MechaLeague</h1>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                  The premier robotics competition league for students
                </p>
              </div>
              <div className="space-x-4 animate-in fade-in slide-in-from-bottom-5 duration-1000 delay-300">
                <Button asChild className="transition-transform hover:scale-105">
                  <Link href="/teams">Explore Teams</Link>
                </Button>
                <Button variant="outline" asChild className="transition-transform hover:scale-105">
                  <Link href="/tournaments">View Tournaments</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-background">
          <div className="container px-4 md:px-6 max-w-[1600px] mx-auto">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Featured Tournament</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                  Check out our latest competition
                </p>
              </div>
            </div>

            <div className="mx-auto max-w-5xl">
              <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <div className="aspect-video relative">
                  <Image
                    src="/images/maxresdefault.jpg"
                    alt="MechaLeague Founders Championship"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                      Completed
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle>MechaLeague Founders Championship</CardTitle>
                  <p className="text-sm text-muted-foreground">Presented by Prepa Tec</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>November 21, 2024</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>Saltillo, Coahuila, Mexico</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>14 teams</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Trophy className="h-4 w-4 text-muted-foreground" />
                      <span>Winner: Alliance 4 (Team 3, Team 6, Team 8)</span>
                    </div>
                  </div>
                  <p className="mt-4 text-sm text-muted-foreground">
                    The inaugural competition of MechaLeague featuring 14 teams competing in 3v3 alliances format.
                  </p>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" asChild className="w-full hover:bg-primary/10 transition-colors">
                    <Link href="/tournaments/mechaleague-founders-championship">View results</Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-muted/30">
          <div className="container px-4 md:px-6 max-w-[1600px] mx-auto">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-8">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Top Teams</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                  Meet the leading teams in MechaLeague
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {topTeams.map((team, index) => (
                <Link href={`/teams/${team.id}`} key={team.id} className="group">
                  <Card className="overflow-hidden h-full transition-all duration-300 hover:shadow-lg group-hover:border-primary/50">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <div className="relative h-16 w-16 rounded-full overflow-hidden border-2 border-muted group-hover:border-primary transition-colors">
                          {team.id === "team-minus-1" ? (
                            <Image src="/images/vector-1-team.png" alt={team.name} fill className="object-cover" />
                          ) : (
                            <Image src="/placeholder.svg" alt={team.name} fill className="object-cover" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-bold text-lg group-hover:text-primary transition-colors">{team.name}</h3>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                            <Trophy className="h-4 w-4" />
                            <span>Rank: #{team.rank}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Users className="h-4 w-4" />
                            <span>{team.members} members</span>
                          </div>
                        </div>
                        <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="flex justify-center mt-8">
              <Button asChild className="transition-transform hover:scale-105">
                <Link href="/teams">View all teams</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-background">
          <div className="container px-4 md:px-6 max-w-[1600px] mx-auto">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Join MechaLeague</h2>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                  Ready to take your robotics skills to the next level?
                </p>
              </div>
              <div className="mx-auto w-full max-w-sm space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <Button asChild size="lg" className="animate-pulse">
                    <Link href="https://tally.so/r/wMGpD0" target="_blank" rel="noopener noreferrer">
                      Register your team
                    </Link>
                  </Button>
                  <Button variant="outline" asChild size="lg">
                    <Link href="/about">Learn more</Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row max-w-[1600px]">
          <p className="text-sm text-muted-foreground">© 2024 MechaLeague. All rights reserved.</p>
          <div className="flex gap-4">
            <Link
              href="/terms"
              className="text-sm text-muted-foreground hover:underline hover:text-primary transition-colors"
            >
              Terms
            </Link>
            <Link
              href="/privacy"
              className="text-sm text-muted-foreground hover:underline hover:text-primary transition-colors"
            >
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

const topTeams = [
  {
    id: "team-12",
    name: "Equipo 12",
    rank: 1,
    members: 2,
    logo: "/placeholder.svg",
  },
  {
    id: "team-5",
    name: "Equipo 5",
    rank: 2,
    members: 3,
    logo: "/placeholder.svg",
  },
  {
    id: "team-minus-1",
    name: "Vector -1",
    rank: 3,
    members: 3,
    logo: "/images/vector-1-team.png",
  },
]
