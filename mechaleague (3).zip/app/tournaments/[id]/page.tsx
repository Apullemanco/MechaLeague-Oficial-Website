"use client"
import Link from "next/link"
import Image from "next/image"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Calendar, MapPin, Search, Trophy, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import TournamentNotFound from "./not-found"

export default function TournamentDetailPage() {
  const params = useParams()
  const router = useRouter()
  const tournamentId = params.id

  // Find the tournament data based on the ID from the URL
  const tournament = tournaments.find((t) => t.id === tournamentId)

  if (!tournament) {
    return <TournamentNotFound />
  }

  // Helper function to get team ID from name
  const getTeamId = (teamName) => {
    if (teamName === "Vector -1") return "team-minus-1"
    if (teamName.startsWith("Team ")) {
      const num = teamName.replace("Team ", "")
      return `team-${num}`
    }
    return ""
  }

  return (
    <div className="flex flex-col min-h-screen max-w-[1920px] mx-auto">
      <header className="sticky top-0 z-40 w-full border-b bg-background">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2 transition-transform hover:scale-105">
              <div className="relative w-8 h-8">
                <Image src="/images/mechaleague-logo.png" alt="MechaLeague" width={32} height={32} />
              </div>
              <span className="inline-block font-bold">MechaLeague</span>
            </Link>
            <nav className="hidden md:flex gap-6">
              <Link
                href="/"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Home
              </Link>
              <Link
                href="/teams"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Teams
              </Link>
              <Link href="/tournaments" className="flex items-center text-sm font-medium text-foreground">
                Tournaments
              </Link>
              <Link
                href="/about"
                className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                About
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <div className="relative w-full max-w-sm mr-4 hidden md:flex">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search teams, tournaments..."
                className="pl-8 w-full transition-all focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <nav className="flex items-center space-x-2">
              <Button variant="outline" size="icon" asChild className="hover:bg-primary/10 transition-colors">
                <Link href="/search">
                  <Search className="h-4 w-4" />
                  <span className="sr-only">Search</span>
                </Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <div className="container px-4 py-6 md:py-8 max-w-7xl mx-auto">
          <Button variant="ghost" size="sm" asChild className="mb-6 hover:scale-105 transition-transform">
            <Link href="/tournaments">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to tournaments
            </Link>
          </Button>

          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-1">
              <Card className="hover:shadow-lg transition-shadow duration-300">
                <div className="aspect-video relative">
                  <Link href={`/tournaments/${tournament.id}`}>
                    <Image src="/images/maxresdefault.jpg" alt={tournament.name} fill className="object-cover" />
                  </Link>
                </div>
                <CardContent className="p-6">
                  <h1 className="text-2xl font-bold">{tournament.name}</h1>
                  <div className="text-sm text-muted-foreground mb-3">Presented by Prepa Tec</div>
                  <div className="space-y-3 mt-4">
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      <span>{tournament.date}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <span>{tournament.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span>{tournament.teams} teams</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Trophy className="h-4 w-4 text-muted-foreground" />
                      <span>Winner: {tournament.winner}</span>
                    </div>
                  </div>
                  <Separator className="my-4" />
                  <div>
                    <h3 className="font-medium mb-2">Tournament format</h3>
                    <p className="text-sm text-muted-foreground">
                      Teams compete in 3v3 alliances (Blue Alliance vs Red Alliance) in a series of qualification
                      matches.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2">
              <Tabs defaultValue="qualification" className="animate-in fade-in duration-500">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="qualification" className="transition-all hover:bg-primary/20">
                    Qualification
                  </TabsTrigger>
                  <TabsTrigger value="playoff" className="transition-all hover:bg-primary/20">
                    Playoff
                  </TabsTrigger>
                  <TabsTrigger value="semifinal" className="transition-all hover:bg-primary/20">
                    Semifinal
                  </TabsTrigger>
                  <TabsTrigger value="final" className="transition-all hover:bg-primary/20">
                    Final
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="qualification" className="mt-6 animate-in slide-in-from-left duration-300">
                  <Card className="hover:shadow-lg transition-shadow duration-300">
                    <CardHeader>
                      <CardTitle>Qualification matches</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Match</TableHead>
                              <TableHead>Blue Alliance</TableHead>
                              <TableHead>Score</TableHead>
                              <TableHead>Red Alliance</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {tournament.qualificationMatches.map((match, index) => (
                              <TableRow key={index} className="hover:bg-muted/50 transition-colors">
                                <TableCell className="font-medium">Q{index + 1}</TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <div className="flex items-center space-x-2">
                                      {match.blueAlliance.map((team, teamIndex) => (
                                        <Link href={`/teams/${getTeamId(team)}`} key={teamIndex}>
                                          <Badge
                                            variant="outline"
                                            className="bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer transition-colors"
                                          >
                                            {team}
                                          </Badge>
                                        </Link>
                                      ))}
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <span className="font-bold text-blue-600">{match.blueScore}</span>
                                    <span>-</span>
                                    <span className="font-bold text-red-600">{match.redScore}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <div className="flex items-center space-x-2">
                                      {match.redAlliance.map((team, teamIndex) => (
                                        <Link href={`/teams/${getTeamId(team)}`} key={teamIndex}>
                                          <Badge
                                            variant="outline"
                                            className="bg-red-100 text-red-800 hover:bg-red-200 cursor-pointer transition-colors"
                                          >
                                            {team}
                                          </Badge>
                                        </Link>
                                      ))}
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="playoff" className="mt-6 animate-in slide-in-from-left duration-300">
                  <Card className="hover:shadow-lg transition-shadow duration-300">
                    <CardHeader>
                      <CardTitle>Playoff matches</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-6">
                        <h3 className="text-lg font-medium mb-3">Alliance selection</h3>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          {tournament.alliances.map((alliance, index) => (
                            <Card key={index} className="hover:shadow-md transition-shadow duration-300">
                              <CardHeader className="py-3">
                                <CardTitle className="text-base">Alliance {index + 1}</CardTitle>
                              </CardHeader>
                              <CardContent className="py-2">
                                <div className="space-y-2">
                                  {alliance.teams.map((team, teamIndex) => (
                                    <Link href={`/teams/${getTeamId(team)}`} key={teamIndex}>
                                      <div className="flex items-center gap-2 hover:bg-muted p-1 rounded cursor-pointer transition-colors">
                                        <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-xs">
                                          {teamIndex + 1}
                                        </div>
                                        <span>{team}</span>
                                      </div>
                                    </Link>
                                  ))}
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>

                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Match</TableHead>
                              <TableHead>Blue Alliance</TableHead>
                              <TableHead>Score</TableHead>
                              <TableHead>Red Alliance</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {tournament.playoffMatches.map((match, index) => (
                              <TableRow key={index} className="hover:bg-muted/50 transition-colors">
                                <TableCell className="font-medium">M{index + 1}</TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <Link href={`#alliance-${match.blueAlliance}`}>
                                      <div className="flex items-center space-x-2">
                                        <Badge
                                          variant="outline"
                                          className="bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer transition-colors"
                                        >
                                          Alliance {match.blueAlliance}
                                        </Badge>
                                      </div>
                                    </Link>
                                    <div className="text-xs text-muted-foreground">
                                      {tournament.alliances[match.blueAlliance - 1].teams.map((team, teamIndex) => (
                                        <span key={teamIndex}>
                                          <Link
                                            href={`/teams/${getTeamId(team)}`}
                                            className="hover:underline hover:text-primary transition-colors"
                                          >
                                            {team}
                                          </Link>
                                          {teamIndex < tournament.alliances[match.blueAlliance - 1].teams.length - 1
                                            ? ", "
                                            : ""}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <span className="font-bold text-blue-600">{match.blueScore}</span>
                                    <span>-</span>
                                    <span className="font-bold text-red-600">{match.redScore}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <Link href={`#alliance-${match.redAlliance}`}>
                                      <div className="flex items-center space-x-2">
                                        <Badge
                                          variant="outline"
                                          className="bg-red-100 text-red-800 hover:bg-red-200 cursor-pointer transition-colors"
                                        >
                                          Alliance {match.redAlliance}
                                        </Badge>
                                      </div>
                                    </Link>
                                    <div className="text-xs text-muted-foreground">
                                      {tournament.alliances[match.redAlliance - 1].teams.map((team, teamIndex) => (
                                        <span key={teamIndex}>
                                          <Link
                                            href={`/teams/${getTeamId(team)}`}
                                            className="hover:underline hover:text-primary transition-colors"
                                          >
                                            {team}
                                          </Link>
                                          {teamIndex < tournament.alliances[match.redAlliance - 1].teams.length - 1
                                            ? ", "
                                            : ""}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="semifinal" className="mt-6 animate-in slide-in-from-left duration-300">
                  <Card className="hover:shadow-lg transition-shadow duration-300">
                    <CardHeader>
                      <CardTitle>Semifinal matches</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Match</TableHead>
                              <TableHead>Blue Alliance</TableHead>
                              <TableHead>Score</TableHead>
                              <TableHead>Red Alliance</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {tournament.semifinalMatches.map((match, index) => (
                              <TableRow key={index} className="hover:bg-muted/50 transition-colors">
                                <TableCell className="font-medium">S{index + 1}</TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <Link href={`#alliance-${match.blueAlliance}`}>
                                      <div className="flex items-center space-x-2">
                                        <Badge
                                          variant="outline"
                                          className="bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer transition-colors"
                                        >
                                          Alliance {match.blueAlliance}
                                        </Badge>
                                      </div>
                                    </Link>
                                    <div className="text-xs text-muted-foreground">
                                      {tournament.alliances[match.blueAlliance - 1].teams.map((team, teamIndex) => (
                                        <span key={teamIndex}>
                                          <Link
                                            href={`/teams/${getTeamId(team)}`}
                                            className="hover:underline hover:text-primary transition-colors"
                                          >
                                            {team}
                                          </Link>
                                          {teamIndex < tournament.alliances[match.blueAlliance - 1].teams.length - 1
                                            ? ", "
                                            : ""}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <span className="font-bold text-blue-600">{match.blueScore}</span>
                                    <span>-</span>
                                    <span className="font-bold text-red-600">{match.redScore}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <Link href={`#alliance-${match.redAlliance}`}>
                                      <div className="flex items-center space-x-2">
                                        <Badge
                                          variant="outline"
                                          className="bg-red-100 text-red-800 hover:bg-red-200 cursor-pointer transition-colors"
                                        >
                                          Alliance {match.redAlliance}
                                        </Badge>
                                      </div>
                                    </Link>
                                    <div className="text-xs text-muted-foreground">
                                      {tournament.alliances[match.redAlliance - 1].teams.map((team, teamIndex) => (
                                        <span key={teamIndex}>
                                          <Link
                                            href={`/teams/${getTeamId(team)}`}
                                            className="hover:underline hover:text-primary transition-colors"
                                          >
                                            {team}
                                          </Link>
                                          {teamIndex < tournament.alliances[match.redAlliance - 1].teams.length - 1
                                            ? ", "
                                            : ""}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="final" className="mt-6 animate-in slide-in-from-left duration-300">
                  <Card className="hover:shadow-lg transition-shadow duration-300">
                    <CardHeader>
                      <CardTitle>Final match</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Match</TableHead>
                              <TableHead>Blue Alliance</TableHead>
                              <TableHead>Score</TableHead>
                              <TableHead>Red Alliance</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {tournament.finalMatch && (
                              <TableRow className="hover:bg-muted/50 transition-colors">
                                <TableCell className="font-medium">FINAL</TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <Link href={`#alliance-${tournament.finalMatch.blueAlliance}`}>
                                      <div className="flex items-center space-x-2">
                                        <Badge
                                          variant="outline"
                                          className="bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer transition-colors"
                                        >
                                          Alliance {tournament.finalMatch.blueAlliance}
                                        </Badge>
                                      </div>
                                    </Link>
                                    <div className="text-xs text-muted-foreground">
                                      {tournament.alliances[tournament.finalMatch.blueAlliance - 1].teams.map(
                                        (team, teamIndex) => (
                                          <span key={teamIndex}>
                                            <Link
                                              href={`/teams/${getTeamId(team)}`}
                                              className="hover:underline hover:text-primary transition-colors"
                                            >
                                              {team}
                                            </Link>
                                            {teamIndex <
                                            tournament.alliances[tournament.finalMatch.blueAlliance - 1].teams.length -
                                              1
                                              ? ", "
                                              : ""}
                                          </span>
                                        ),
                                      )}
                                    </div>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center space-x-2">
                                    <span className="font-bold text-blue-600">{tournament.finalMatch.blueScore}</span>
                                    <span>-</span>
                                    <span className="font-bold text-red-600">{tournament.finalMatch.redScore}</span>
                                  </div>
                                </TableCell>
                                <TableCell>
                                  <div className="flex flex-col space-y-1">
                                    <Link href={`#alliance-${tournament.finalMatch.redAlliance}`}>
                                      <div className="flex items-center space-x-2">
                                        <Badge
                                          variant="outline"
                                          className="bg-red-100 text-red-800 hover:bg-red-200 cursor-pointer transition-colors"
                                        >
                                          Alliance {tournament.finalMatch.redAlliance}
                                        </Badge>
                                      </div>
                                    </Link>
                                    <div className="text-xs text-muted-foreground">
                                      {tournament.alliances[tournament.finalMatch.redAlliance - 1].teams.map(
                                        (team, teamIndex) => (
                                          <span key={teamIndex}>
                                            <Link
                                              href={`/teams/${getTeamId(team)}`}
                                              className="hover:underline hover:text-primary transition-colors"
                                            >
                                              {team}
                                            </Link>
                                            {teamIndex <
                                            tournament.alliances[tournament.finalMatch.redAlliance - 1].teams.length - 1
                                              ? ", "
                                              : ""}
                                          </span>
                                        ),
                                      )}
                                    </div>
                                  </div>
                                </TableCell>
                              </TableRow>
                            )}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <p className="text-sm text-muted-foreground">© 2024 MechaLeague. All rights reserved.</p>
          <div className="flex gap-4">
            <Link
              href="/terms"
              className="text-sm text-muted-foreground hover:underline hover:text-primary transition-colors"
            >
              Terms
            </Link>
            <Link
              href="/privacy"
              className="text-sm text-muted-foreground hover:underline hover:text-primary transition-colors"
            >
              Privacy
            </Link>
            <Link
              href="/contact"
              className="text-sm text-muted-foreground hover:underline hover:text-primary transition-colors"
            >
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

const tournaments = [
  {
    id: "mechaleague-founders-championship",
    name: "MechaLeague Founders Championship",
    date: "November 21, 2024",
    location: "Saltillo, Coahuila, Mexico",
    teams: 14,
    winner: "Alliance 4 (Team 3, Team 6, Team 8)",
    description: "The inaugural competition of MechaLeague featuring 14 teams competing in 3v3 alliances format.",
    image: "/images/maxresdefault.jpg",
    alliances: [
      {
        teams: ["Team 12", "Team 7", "Team 10"],
      },
      {
        teams: ["Team 5", "Team 13", "Team 4"],
      },
      {
        teams: ["Vector -1", "Team 11", "Team 14"],
      },
      {
        teams: ["Team 3", "Team 6", "Team 8"],
      },
    ],
    qualificationMatches: [
      {
        blueAlliance: ["Vector -1", "Team 11", "Team 5"],
        redAlliance: ["Team 3", "Team 13", "Team 9"],
        blueScore: 12,
        redScore: 8,
      },
      {
        blueAlliance: ["Team 14", "Team 6", "Team 7"],
        redAlliance: ["Team 10", "Team 2", "Team 8"],
        blueScore: 8,
        redScore: 13,
      },
      {
        blueAlliance: ["Team 2", "Team 8", "Team 10"],
        redAlliance: ["Team 4", "Vector -1", "Team 12"],
        blueScore: 11,
        redScore: 17,
      },
      {
        blueAlliance: ["Team 11", "Team 14", "Team 6"],
        redAlliance: ["Team 12", "Team 3", "Team 13"],
        blueScore: 10,
        redScore: 14,
      },
      {
        blueAlliance: ["Team 4", "Team 5", "Team 13"],
        redAlliance: ["Team 9", "Team 3", "Team 7"],
        blueScore: 16,
        redScore: 13,
      },
      {
        blueAlliance: ["Vector -1", "Team 6", "Team 9"],
        redAlliance: ["Team 2", "Team 14", "Team 11"],
        blueScore: 6,
        redScore: 14,
      },
      {
        blueAlliance: ["Team 4", "Team 12", "Team 8"],
        redAlliance: ["Team 7", "Team 5", "Team 10"],
        blueScore: 10,
        redScore: 16,
      },
      {
        blueAlliance: ["Team 3", "Team 11", "Team 6"],
        redAlliance: ["Team 9", "Team 2", "Team 8"],
        blueScore: 18,
        redScore: 14,
      },
      {
        blueAlliance: ["Team 5", "Team 7", "Team 10"],
        redAlliance: ["Vector -1", "Team 12", "Team 13"],
        blueScore: 18,
        redScore: 4,
      },
      {
        blueAlliance: ["Team 14", "Team 4", "Team 9"],
        redAlliance: ["Team 6", "Team 3", "Vector -1"],
        blueScore: 8,
        redScore: 16,
      },
      {
        blueAlliance: ["Team 8", "Team 2", "Team 12"],
        redAlliance: ["Team 10", "Team 11", "Team 5"],
        blueScore: 14,
        redScore: 4,
      },
      {
        blueAlliance: ["Team 7", "Team 14", "Team 3"],
        redAlliance: ["Team 6", "Team 13", "Team 9"],
        blueScore: 15,
        redScore: 5,
      },
      {
        blueAlliance: ["Team 11", "Vector -1", "Team 8"],
        redAlliance: ["Team 12", "Team 10", "Team 4"],
        blueScore: 13,
        redScore: 18,
      },
      {
        blueAlliance: ["Team 5", "Team 13", "Team 4"],
        redAlliance: ["Team 14", "Team 2", "Team 7"],
        blueScore: 6,
        redScore: 11,
      },
    ],
    playoffMatches: [
      {
        blueAlliance: 4,
        redAlliance: 1,
        blueScore: 12,
        redScore: 14,
      },
      {
        blueAlliance: 3,
        redAlliance: 2,
        blueScore: 9,
        redScore: 13,
      },
    ],
    semifinalMatches: [
      {
        blueAlliance: 2,
        redAlliance: 1,
        blueScore: 12,
        redScore: 11,
      },
      {
        blueAlliance: 4,
        redAlliance: 3,
        blueScore: 18,
        redScore: 4,
      },
    ],
    finalMatch: {
      blueAlliance: 4,
      redAlliance: 1,
      blueScore: 20,
      redScore: 13,
    },
    participatingTeams: [
      {
        id: "team-minus-1",
        name: "Vector -1",
        rank: 3,
      },
      {
        id: "team-2",
        name: "Equipo 2",
        rank: 8,
      },
      {
        id: "team-3",
        name: "Equipo 3",
        rank: 4,
      },
      {
        id: "team-4",
        name: "Equipo 4",
        rank: 5,
      },
      {
        id: "team-5",
        name: "Equipo 5",
        rank: 2,
      },
      {
        id: "team-6",
        name: "Equipo 6",
        rank: 11,
      },
      {
        id: "team-7",
        name: "Equipo 7",
        rank: 6,
      },
      {
        id: "team-8",
        name: "Equipo 8",
        rank: 9,
      },
      {
        id: "team-9",
        name: "Equipo 9",
        rank: 14,
      },
      {
        id: "team-10",
        name: "Equipo 10",
        rank: 7,
      },
      {
        id: "team-11",
        name: "Equipo 11",
        rank: 12,
      },
      {
        id: "team-12",
        name: "Equipo 12",
        rank: 1,
      },
      {
        id: "team-13",
        name: "Equipo 13",
        rank: 10,
      },
      {
        id: "team-14",
        name: "Equipo 14",
        rank: 13,
      },
    ],
  },
]
