import Link from "next/link"
import Image from "next/image"
import { Calendar, MapPin, Trophy, Users, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

export default function TournamentsPage() {
  return (
    <div className="flex flex-col min-h-screen max-w-[1920px] mx-auto">
      <header className="sticky top-0 z-40 w-full border-b bg-background">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <div className="relative w-8 h-8">
                <Image src="/images/mechaleague-logo.png" alt="MechaLeague" width={32} height={32} />
              </div>
              <span className="inline-block font-bold">MechaLeague</span>
            </Link>
            <nav className="hidden md:flex gap-6">
              <Link href="/" className="flex items-center text-sm font-medium text-muted-foreground">
                Home
              </Link>
              <Link href="/teams" className="flex items-center text-sm font-medium text-muted-foreground">
                Teams
              </Link>
              <Link href="/tournaments" className="flex items-center text-sm font-medium text-foreground">
                Tournaments
              </Link>
              <Link href="/about" className="flex items-center text-sm font-medium text-muted-foreground">
                About
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <div className="relative w-full max-w-sm mr-4 hidden md:flex">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search teams, tournaments..." className="pl-8 w-full" />
            </div>
            <nav className="flex items-center space-x-2">
              <Button variant="outline" size="icon" asChild>
                <Link href="/search">
                  <Search className="h-4 w-4" />
                  <span className="sr-only">Search</span>
                </Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-1 w-full">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted/30">
          <div className="container px-4 md:px-6 max-w-[1600px] mx-auto">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl">MechaLeague tournaments</h1>
                <p className="max-w-[700px] text-muted-foreground md:text-xl/relaxed">
                  Browse upcoming and past tournaments
                </p>
              </div>
            </div>

            <Tabs defaultValue="upcoming" className="mt-8">
              <TabsList className="grid w-full max-w-md mx-auto grid-cols-3">
                <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                <TabsTrigger value="ongoing">Ongoing</TabsTrigger>
                <TabsTrigger value="past">Past</TabsTrigger>
              </TabsList>

              <TabsContent value="upcoming" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {upcomingTournaments.map((tournament, index) => (
                    <Card key={index} className="overflow-hidden">
                      <div className="aspect-video relative">
                        <Image src="/placeholder.svg" alt={tournament.name} fill className="object-cover" />
                        <div className="absolute top-2 right-2">
                          <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                            {tournament.type}
                          </Badge>
                        </div>
                      </div>
                      <CardHeader>
                        <CardTitle>{tournament.name}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.date}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.location}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.teams} teams</span>
                          </div>
                        </div>
                        <p className="mt-4 text-sm text-muted-foreground">{tournament.description}</p>
                      </CardContent>
                      <CardFooter>
                        <Button asChild className="w-full">
                          <Link href={`/tournaments/${tournament.id}`}>View details</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="ongoing" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {ongoingTournaments.map((tournament, index) => (
                    <Card key={index} className="overflow-hidden">
                      <div className="aspect-video relative">
                        <Image src="/placeholder.svg" alt={tournament.name} fill className="object-cover" />
                        <div className="absolute top-2 right-2">
                          <Badge className="bg-green-500 text-white">Live</Badge>
                        </div>
                      </div>
                      <CardHeader>
                        <CardTitle>{tournament.name}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.date}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.location}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.teams} teams</span>
                          </div>
                        </div>
                        <p className="mt-4 text-sm text-muted-foreground">{tournament.description}</p>
                      </CardContent>
                      <CardFooter>
                        <Button asChild className="w-full">
                          <Link href={`/tournaments/${tournament.id}`}>View live results</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="past" className="mt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {pastTournaments.map((tournament, index) => (
                    <Card key={index} className="overflow-hidden">
                      <div className="aspect-video relative">
                        <Image src="/images/maxresdefault.jpg" alt={tournament.name} fill className="object-cover" />
                        <div className="absolute top-2 right-2">
                          <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                            Completed
                          </Badge>
                        </div>
                      </div>
                      <CardHeader>
                        <CardTitle>{tournament.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">Presented by Prepa Tec</p>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.date}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.location}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span>{tournament.teams} teams</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm">
                            <Trophy className="h-4 w-4 text-muted-foreground" />
                            <span>Winner: {tournament.winner}</span>
                          </div>
                        </div>
                        <p className="mt-4 text-sm text-muted-foreground">{tournament.description}</p>
                      </CardContent>
                      <CardFooter>
                        <Button variant="outline" asChild className="w-full">
                          <Link href={`/tournaments/${tournament.id}`}>View results</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row max-w-[1600px]">
          <p className="text-sm text-muted-foreground">© 2024 MechaLeague. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

const pastTournaments = [
  {
    id: "mechaleague-founders-championship",
    name: "MechaLeague Founders Championship",
    date: "November 21, 2024",
    location: "Saltillo, Coahuila, Mexico",
    teams: 14,
    winner: "Alliance 4 (Team 3, Team 6, Team 8)",
    description:
      "The inaugural competition of MechaLeague featuring 14 teams competing in 3v3 alliances format. Presented by Prepa Tec.",
    image: "/images/maxresdefault.jpg",
  },
]

const upcomingTournaments = [
  {
    id: "chemistry-quest",
    name: "Chemistry Quest",
    date: "TBD",
    location: "Saltillo, Coahuila, Mexico",
    teams: "TBD",
    description: "An upcoming MechaLeague competition focused on chemistry-related challenges.",
    type: "Regional",
    image: "/placeholder.svg",
  },
]
const ongoingTournaments = []
