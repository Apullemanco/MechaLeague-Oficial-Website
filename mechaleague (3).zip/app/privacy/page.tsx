import Link from "next/link"
import Image from "next/image"
import { Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function PrivacyPage() {
  return (
    <div className="flex flex-col min-h-screen max-w-[1920px] mx-auto">
      <header className="sticky top-0 z-40 w-full border-b bg-background">
        <div className="container flex h-16 items-center space-x-4 sm:justify-between sm:space-x-0">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <div className="relative w-8 h-8">
                <Image src="/images/mechaleague-logo.png" alt="MechaLeague" width={32} height={32} />
              </div>
              <span className="inline-block font-bold">MechaLeague</span>
            </Link>
            <nav className="hidden md:flex gap-6">
              <Link href="/" className="flex items-center text-sm font-medium text-muted-foreground">
                Home
              </Link>
              <Link href="/teams" className="flex items-center text-sm font-medium text-muted-foreground">
                Teams
              </Link>
              <Link href="/tournaments" className="flex items-center text-sm font-medium text-muted-foreground">
                Tournaments
              </Link>
              <Link href="/about" className="flex items-center text-sm font-medium text-muted-foreground">
                About
              </Link>
            </nav>
          </div>
          <div className="flex flex-1 items-center justify-end space-x-4">
            <div className="relative w-full max-w-sm mr-4 hidden md:flex">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search teams, tournaments..." className="pl-8 w-full" />
            </div>
            <nav className="flex items-center space-x-2">
              <Button variant="outline" size="icon" asChild>
                <Link href="/search">
                  <Search className="h-4 w-4" />
                  <span className="sr-only">Search</span>
                </Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-1 w-full">
        <section className="w-full py-12 md:py-24 bg-muted/30">
          <div className="container px-4 md:px-6 max-w-[1600px] mx-auto">
            <div className="max-w-3xl mx-auto">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl mb-6">PRIVACY</h1>
              <div className="prose max-w-none">
                <p>
                  At MechaLeague, we value and protect your privacy. We only collect the information necessary for
                  registration, participation, and the improvement of our events. We do not share personal data with
                  third parties unless required by law or with your consent. Cookies are used only to enhance your
                  experience on our site. If you have any questions about how we handle your data, feel free to contact
                  us.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row max-w-[1600px]">
          <p className="text-sm text-muted-foreground">© 2024 MechaLeague. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm font-medium">
              Privacy
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
